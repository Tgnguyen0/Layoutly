import { useEffect } from 'react'
import { applyResponsiveScale } from './lib/responsiveScale.js'
import Page from './pages/page.jsx'
import './styles/layoutly.css'

import './styles/view-transitions.css'
export default function App() {
  useEffect(() => { applyResponsiveScale() }, [])
  return <Page />
}
