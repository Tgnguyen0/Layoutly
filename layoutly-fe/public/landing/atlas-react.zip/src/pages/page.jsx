export default function Page() {
  return (
    <main className="figma-page" style={{
      '--figma-width': 1440.0,
      '--figma-height': 960.0,
      '--figma-offset-x': 0.0,
      '--figma-offset-y': 0.0,
    }}>
      <section className="figma-canvas">
        <div className="figma-node atlas node-screen" id="node-screen" data-figma-type="FRAME" data-figma-name={"Atlas"}>
          <p className="figma-node atlas-brand node-atlas-brand" id="node-atlas-brand" data-figma-type="TEXT" data-figma-name={"atlas-brand"}>{"atlas."}</p>
          <p className="figma-node atlas-nav node-atlas-nav" id="node-atlas-nav" data-figma-type="TEXT" data-figma-name={"atlas-nav"}>{"Destinations       Our story       Journal       Plan a trip ↗"}</p>
          <div className="figma-node atlas-landscape node-atlas-landscape" id="node-atlas-landscape" data-figma-type="RECTANGLE" data-figma-name={"atlas-landscape"} />
          <div className="figma-node atlas-shade node-atlas-shade" id="node-atlas-shade" data-figma-type="RECTANGLE" data-figma-name={"atlas-shade"} />
          <p className="figma-node atlas-eyebrow node-atlas-eyebrow" id="node-atlas-eyebrow" data-figma-type="TEXT" data-figma-name={"atlas-eyebrow"}>{"FOR THE CURIOUS. FOR THE WANDERERS."}</p>
          <p className="figma-node atlas-heading node-atlas-heading" id="node-atlas-heading" data-figma-type="TEXT" data-figma-name={"atlas-heading"}>{"Go somewhere\nthat stays with you."}</p>
          <p className="figma-node atlas-description node-atlas-description" id="node-atlas-description" data-figma-type="TEXT" data-figma-name={"atlas-description"}>{"Unhurried journeys. Extraordinary places.\nFind a little more of yourself along the way."}</p>
          <div className="figma-node atlas-button node-atlas-button" id="node-atlas-button" data-figma-type="RECTANGLE" data-figma-name={"atlas-button"} />
          <p className="figma-node atlas-button-label node-atlas-button-label" id="node-atlas-button-label" data-figma-type="TEXT" data-figma-name={"atlas-button-label"}>{"Explore journeys  ↗"}</p>
          <p className="figma-node atlas-section node-atlas-section" id="node-atlas-section" data-figma-type="TEXT" data-figma-name={"atlas-section"}>{"A different kind of getting away."}</p>
          <div className="figma-node atlas-tile-0 node-atlas-tile-0" id="node-atlas-tile-0" data-figma-type="RECTANGLE" data-figma-name={"atlas-tile-0"} />
          <p className="figma-node atlas-tile-title-0 node-atlas-tile-title-0" id="node-atlas-tile-title-0" data-figma-type="TEXT" data-figma-name={"atlas-tile-title-0"}>{"Slow adventures"}</p>
          <p className="figma-node atlas-tile-text-0 node-atlas-tile-text-0" id="node-atlas-tile-text-0" data-figma-type="TEXT" data-figma-name={"atlas-tile-text-0"}>{"Take the scenic route."}</p>
          <div className="figma-node atlas-tile-1 node-atlas-tile-1" id="node-atlas-tile-1" data-figma-type="RECTANGLE" data-figma-name={"atlas-tile-1"} />
          <p className="figma-node atlas-tile-title-1 node-atlas-tile-title-1" id="node-atlas-tile-title-1" data-figma-type="TEXT" data-figma-name={"atlas-tile-title-1"}>{"Local connections"}</p>
          <p className="figma-node atlas-tile-text-1 node-atlas-tile-text-1" id="node-atlas-tile-text-1" data-figma-type="TEXT" data-figma-name={"atlas-tile-text-1"}>{"Meet the people behind the place."}</p>
          <div className="figma-node atlas-tile-2 node-atlas-tile-2" id="node-atlas-tile-2" data-figma-type="RECTANGLE" data-figma-name={"atlas-tile-2"} />
          <p className="figma-node atlas-tile-title-2 node-atlas-tile-title-2" id="node-atlas-tile-title-2" data-figma-type="TEXT" data-figma-name={"atlas-tile-title-2"}>{"Room to explore"}</p>
          <p className="figma-node atlas-tile-text-2 node-atlas-tile-text-2" id="node-atlas-tile-text-2" data-figma-type="TEXT" data-figma-name={"atlas-tile-text-2"}>{"Make the journey your own."}</p>
        </div>
      </section>
    </main>
  )
}
